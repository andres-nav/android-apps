package com.andresnav.trackmyshoes.utils;


import android.util.Log;

public class Utils {

    private static final String TAG = "supertag";

    public static void print(String string) {
        Log.d(TAG, string);
    }
}
